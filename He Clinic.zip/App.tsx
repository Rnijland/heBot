// This file is no longer needed - the app now uses /app/page.tsx
// You can safely delete this file
export {};